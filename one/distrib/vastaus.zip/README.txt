Tekijä: Ville Kuokkanen
Itsearvio: 1/5. Toteutettu makeGenCyl, tor.swp toimii

Tehtävä tuntui hankalammalta verrattuna assignment 0:aan.
Hankalinta oli tehtävän sisäistämien ja miettiä, miten vektorilaskut
pitäisi tehdä
