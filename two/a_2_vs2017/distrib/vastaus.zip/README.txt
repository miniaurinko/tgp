Tekij�: Ville Kuokkanen
arvio 2/5, matrixstack, tiedostonluku ja pallot piirtyv�t nivelten kohdalle
Teht�v� oli ok. Hankalinta oli toiminta osoittimien ja -> operaattorin kanssa.